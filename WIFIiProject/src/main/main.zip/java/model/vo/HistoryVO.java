package model.vo;

import lombok.*;

@Data
@AllArgsConstructor
public class HistoryVO {


   private String id;
   private Double lat;
    private Double lnt;
    private String date;



}
